import Web3 from 'web3';
import { REWARD_CONTRACT, MAIN_CONTRACT, PROXY_CONTRACT } from './utils/ContractDetails';
const web3 = new Web3(Web3.givenProvider || "ws://localhost:8545");
const Contract = new web3.eth.Contract(REWARD_CONTRACT.abi, REWARD_CONTRACT.address);
export const Contract_Proxy = new web3.eth.Contract(MAIN_CONTRACT.abi, PROXY_CONTRACT.address);
console.log(Contract_Proxy)
console.log(Contract)
export default Contract;