
const { Client, Data } =  require("@bandprotocol/bandchain.js")

async function getReferenceData() {
  const grpcEndpoint = 'https://poa-api.bandchain.org'
  const client = new Client(grpcEndpoint)
//   console.log(client)
  const data = await client.getReferenceData(['BAND/USD', 'BTC/ETH', 'EUR/USD', 'EUR/BTC']);
//   console.log(typeof data) // Promise<Data.ReferenceData[]>
}

getReferenceData()