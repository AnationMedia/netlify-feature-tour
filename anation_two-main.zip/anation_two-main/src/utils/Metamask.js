export const connect = async () => {
    if (typeof window.ethereum !== 'undefined') {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        const account = accounts[0];
        return account;
    } else {
        alert('Please Install Metamask!!!')
        return null;
    }
}