import axios from "axios";

export const getTokenDetails = async () => {
    const URL = 'https://api.pancakeswap.info/api/v2/tokens/0x5Ae89b52f6B5D25EBA50f0441F91A81968689D95'
    var details = await axios.get(URL);
    return details;
}