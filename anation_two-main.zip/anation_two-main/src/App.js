import { useState } from "react";
import Header from './components/Header'
import Footer from './components/Footer'
import Reward from './pages/Reward'
import { BrowserRouter, Route, Routes } from "react-router-dom";
function App() {
  const [currentAccount, setCurrentAccount] = useState('');
  return (
    <div className="text-4xl font-bold bg-main">
      <BrowserRouter>
        <Header currentAccount={currentAccount} setCurrentAccount={setCurrentAccount} />
        <Routes>

          <Route path="/" element={<Reward currentAccount={currentAccount} />}></Route>
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
