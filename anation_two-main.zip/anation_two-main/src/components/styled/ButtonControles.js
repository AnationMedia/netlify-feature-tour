import styledComponents from "styled-components";

export const Controle = styledComponents.div
`
display: flex;
columnGap: 10px
`