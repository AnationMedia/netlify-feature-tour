import styledComponents from "styled-components";

export const ChartLabel = styledComponents.div(`
background: '#fff'
`)