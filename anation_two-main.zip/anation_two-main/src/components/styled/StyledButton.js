import styledComponents from "styled-components";

export const StyledButton = styledComponents.button
`

`