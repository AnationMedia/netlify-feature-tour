import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

export function Chart({data2, bg}) {
    const style = {
        container: {
            width: '200px',
            height: '200px'
        }
    }
    ChartJS.register(ArcElement, Tooltip, Legend);
    const data = {
        datasets: [
            {
                data: data2,
                backgroundColor: bg,
                borderWidth: 0,
            },
        ],
    };

    return (
        <div style={style.container}>
            <Doughnut  data={data} />
        </div>
    )
}


