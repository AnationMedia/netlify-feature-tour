import React from 'react'

export default function Hamburger() {
  const style = {
      line: {
          height: '2px',
          background: '#fff'
      }
  }
    return (
    <>
    <div style={style.line}></div>
    <div style={style.line}></div>
    <div style={style.line}></div>
    </>
  )
}
