import React from 'react'
import WidgetContainer from '../../components/OnramperWidget'
import SectionOne from './SectionOne'
import SectionThree from './SectionThree'
import SectionTwo from './SectionTwo'

export default function index({ currentAccount }) {
  const style = {
    container: {
      padding: '350px  0 130px 0'
    }
  }
  return (
    <div className='container-div'>

      <div className='reward-container'>
        <SectionOne currentAccount={currentAccount} />
        <SectionTwo />
        <SectionThree />
      </div>
      {/* <iframe
        src="https://widget.onramper.com?color=266677&apiKey=pk_test_x5M_5fdXzn1fxK04seu0JgFjGsu7CH8lOvS9xZWzuSM0"
        height="600px"
        width="440px"
        title="Onramper widget"
        allow="accelerometer;
  autoplay; camera; gyroscope; payment"
        style={{
          boxShadow: '1px 1px 1px 1px rgba(0,0,0,0.2)',
          width: '100%',
          marginBottom: '50px'
        }}
      >
        <a href="https://widget.onramper.com" target="_blank">Buy crypto</a>
      </iframe> */}
    </div>
  )
}
